package com.wangqiang.pojo;
import lombok.Data;

/**
 * @version : V1.0
 * @ClassName: User
 * @Description: TODO
 * @Auther: wangqiang
 * @Date: 2020/2/25 19:29
 */
@Data
public class User {
    private int id;
    private String userName;
    private String password;
}
