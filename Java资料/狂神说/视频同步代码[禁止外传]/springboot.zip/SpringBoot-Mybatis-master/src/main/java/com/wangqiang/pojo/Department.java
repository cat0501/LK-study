package com.wangqiang.pojo;

import lombok.Data;

/**
 * @version : V1.0
 * @ClassName: Department
 * @Description: TODO
 * @Auther: wangqiang
 * @Date: 2020/2/25 19:30
 */
@Data
public class Department {
    private int id;
    private String departmentName;
}
